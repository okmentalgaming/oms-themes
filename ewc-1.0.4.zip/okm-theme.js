/* OK Mental theme runtime — client colours + background video.
 * Every overlay links okm-custom.css (written by the app: only CSS custom
 * properties) and loads this file. It
 *   - gives canvas code the current colours: okmC('--okm-…', fallback)
 *   - swaps <video data-okm-video="bg"> to the client's video (--okm-video-bg)
 *   - re-reads okm-custom.css when the app saves, so OBS updates live
 * Without okm-custom.css every overlay keeps its original look.
 */
(function () {
  var root = document.documentElement;
  var cache = {};

  function prop(name) {
    if (!(name in cache)) {
      var v = '';
      try { v = getComputedStyle(root).getPropertyValue(name).trim(); } catch (e) {}
      cache[name] = v;
    }
    return cache[name];
  }

  window.okmC = function (name, fallback) { return prop(name) || fallback; };

  function unquote(v) {
    v = (v || '').trim();
    if (v.length > 1 && (v.charAt(0) === '"' || v.charAt(0) === "'") && v.charAt(v.length - 1) === v.charAt(0)) v = v.slice(1, -1);
    return v.replace(/\\(.)/g, '$1');
  }

  function applyVideos() {
    var vids = document.querySelectorAll('video[data-okm-video]');
    for (var i = 0; i < vids.length; i++) {
      var v = vids[i];
      var want = unquote(prop('--okm-video-' + v.getAttribute('data-okm-video')));
      var cur = v.getAttribute('src') || '';
      if (want === cur) continue;
      if (want) v.setAttribute('src', want); else v.removeAttribute('src');
      try { v.load(); var p = v.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
    }
  }

  function reloadCss(rev) {
    var old = document.getElementById('okm-custom-css');
    var l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = 'okm-custom.css?r=' + encodeURIComponent(rev);
    l.onload = l.onerror = function () {
      if (old && old.parentNode) old.parentNode.removeChild(old);
      l.id = 'okm-custom-css';
      cache = {};
      applyVideos();
      try { window.dispatchEvent(new Event('okm-theme-change')); } catch (e) {}
    };
    (old && old.parentNode ? old.parentNode : document.head).insertBefore(l, old ? old.nextSibling : null);
  }

  var rev = null, misses = 0;
  function poll() {
    if (!window.fetch || location.protocol === 'file:') return;
    fetch('okm/rev', { cache: 'no-store' }).then(function (r) {
      if (!r.ok) throw new Error('rev ' + r.status);
      return r.json();
    }).then(function (j) {
      misses = 0;
      if (rev === null) rev = j.rev;
      else if (j.rev !== rev) { rev = j.rev; reloadCss(j.rev); }
    }).catch(function () { misses++; }).then(function () {
      setTimeout(poll, misses ? Math.min(30000, 2000 * misses) : 2000);
    });
  }

  /* the app's live preview sets colours inline, then calls this */
  window.okmRefresh = function () {
    cache = {};
    applyVideos();
    try { window.dispatchEvent(new Event('okm-theme-change')); } catch (e) {}
  };

  document.addEventListener('okm-refresh', function () { window.okmRefresh(); });

  function start() { applyVideos(); poll(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
